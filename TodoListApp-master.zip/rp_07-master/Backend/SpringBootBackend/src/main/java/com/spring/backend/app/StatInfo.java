package com.spring.backend.app;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="stat_table")
public class StatInfo {
    @Id
    @Column
    private String username;

    @Column
    private String s10172020;

    @Column
    private String s10182020;

    @Column
    private String s10192020;

    @Column
    private String s10202020;

    @Column
    private String s10212020;

    @Column
    private String s10222020;

    @Column
    private String s10232020;

    @Column
    private String s10242020;

    @Column
    private String s10252020;

    @Column
    private String s10262020;

    @Column
    private String s10272020;

    @Column
    private String s10282020;

    @Column
    private String s10292020;

    @Column
    private String s10302020;

    @Column
    private String s10312020;

    @Column
    private String s11012020;

    @Column
    private String s11022020;

    @Column
    private String s11032020;

    @Column
    private String s11042020;

    @Column
    private String s11052020;

    @Column
    private String s11062020;

    @Column
    private String s11072020;

    @Column
    private String s11082020;

    @Column
    private String s11092020;

    @Column
    private String s11102020;

    @Column
    private String s11112020;

    @Column
    private String s11122020;

    @Column
    private String s11132020;

    @Column
    private String s11142020;

    @Column
    private String s11152020;

    @Column
    private String s11162020;

    @Column
    private String s11172020;

    @Column
    private String s11182020;

    @Column
    private String s11192020;

    @Column
    private String s11202020;

    @Column
    private String s11212020;

    @Column
    private String s11222020;

    @Column
    private String s11232020;

    @Column
    private String s11242020;

    @Column
    private String s11252020;

    @Column
    private String s11262020;

    @Column
    private String s11272020;

    @Column
    private String s11282020;

    @Column
    private String s11292020;

    @Column
    private String s11302020;

    public StatInfo(String username, String s10172020,String s10182020,String s10192020,String s10202020,String s10212020,String s10222020,String s10232020, String s10242020,String s10252020, String s10262020,String s10272020, String s10282020,String s10292020, String s10302020,String s10312020,String s11012020,String s11022020,String s11032020,String s11042020,String s11052020,String s11062020,String s11072020,String s11082020,String s11092020,String s11102020,String s11112020,String s11122020,String s11132020,String s11142020,String s11152020,String s11162020,String s11172020,String s11182020,String s11192020,String s11202020,String s11212020,String s11222020,String s11232020,String s11242020,String s11252020,String s11262020,String s11272020,String s11282020,String s11292020,String s11302020){
        this.username=username;
        this.s10172020=s10172020;
        this.s10182020=s10182020;
        this.s10192020=s10192020;
        this.s10202020=s10202020;
        this.s10212020=s10212020;
        this.s10222020=s10222020;
        this.s10232020=s10232020;
        this.s10242020=s10242020;
        this.s10252020=s10252020;
        this.s10262020=s10262020;
        this.s10272020=s10272020;
        this.s10282020=s10282020;
        this.s10292020=s10292020;
        this.s10302020=s10302020;
        this.s10312020=s10312020;
        this.s11012020=s11012020;
        this.s11022020=s11022020;
        this.s11032020=s11032020;
        this.s11042020=s11042020;
        this.s11052020=s11052020;
        this.s11062020=s11062020;
        this.s11072020=s11072020;
        this.s11082020=s11082020;
        this.s11092020=s11092020;
        this.s11102020=s11102020;
        this.s11112020=s11112020;
        this.s11122020=s11122020;
        this.s11132020=s11132020;
        this.s11142020=s11142020;
        this.s11152020=s11152020;
        this.s11162020=s11162020;
        this.s11172020=s11172020;
        this.s11182020=s11182020;
        this.s11192020=s11192020;
        this.s11202020=s11202020;
        this.s11212020=s11212020;
        this.s11222020=s11222020;
        this.s11232020=s11232020;
        this.s11242020=s11242020;
        this.s11252020=s11252020;
        this.s11262020=s11262020;
        this.s11272020=s11272020;
        this.s11282020=s11282020;
        this.s11292020=s11292020;
        this.s11302020=s11302020;
    }

    public StatInfo(){};

    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }

    public String gets10172020() {
        return s10172020;
    }
    public void sets10172020(String s10172020) { this.s10172020=s10172020; }

    public String gets10182020() {
        return s10182020;
    }
    public void sets10182020(String s10182020) {
        this.s10182020=s10182020;
    }

    public String gets10192020() {
        return s10192020;
    }
    public void sets10192020(String s10192020) {
        this.s10192020=s10192020;
    }

    public String gets10202020() {
        return s10202020;
    }
    public void sets10202020(String s10202020) {
        this.s10202020=s10202020;
    }

    public String gets10212020() {
        return s10212020;
    }
    public void sets10212020(String s10212020) {
        this.s10212020=s10212020;
    }

    public String gets10222020() {
        return s10222020;
    }
    public void sets10222020(String s10222020) {
        this.s10222020=s10222020;
    }

    public String gets10232020() {
        return s10232020;
    }
    public void sets10232020(String s10232020) {
        this.s10232020=s10232020;
    }

    public String gets10242020() {
        return s10242020;
    }
    public void sets10242020(String s10242020) {
        this.s10242020=s10242020;
    }

    public String gets10252020() {
        return s10252020;
    }
    public void sets10252020(String s10252020) { this.s10252020=s10252020; }

    public String gets10262020() {
        return s10262020;
    }
    public void sets10262020(String s10262020) {
        this.s10262020=s10262020;
    }

    public String gets10272020() {
        return s10272020;
    }
    public void sets10272020(String s10272020) {
        this.s10272020=s10272020;
    }

    public String gets10282020() {
        return s10282020;
    }
    public void sets10282020(String s10282020) {
        this.s10282020=s10282020;
    }

    public String gets10292020() {
        return s10292020;
    }
    public void sets10292020(String s10292020) {
        this.s10292020=s10292020;
    }

    public String gets10302020() {
        return s10302020;
    }
    public void sets10302020(String s10302020) {
        this.s10302020=s10302020;
    }

    public String gets11012020() {
        return s11012020;
    }
    public void sets11012020(String s11012020) {
        this.s11012020=s11012020;
    }

    public String gets11022020() {
        return s11022020;
    }
    public void sets11022020(String s11022020) {
        this.s11022020=s11022020;
    }

    public String gets11032020() {
        return s11032020;
    }
    public void sets11032020(String s11032020) {
        this.s10232020=s11032020;
    }

    public String gets11042020() {
        return s11042020;
    }
    public void sets11042020(String s11042020) {
        this.s11042020=s11042020;
    }

    public String gets11052020() {
        return s11052020;
    }
    public void sets11052020(String s11052020) {
        this.s11052020=s11052020;
    }

    public String gets11062020() {
        return s11062020;
    }
    public void sets11062020(String s11062020) {
        this.s11062020=s11062020;
    }

    public String gets11072020() {
        return s11072020;
    }
    public void sets11072020(String s11072020) {
        this.s11072020=s11072020;
    }

    public String gets11082020() {
        return s11082020;
    }
    public void sets11082020(String s11082020) {
        this.s11082020=s11082020;
    }

    public String gets11092020() {
        return s11092020;
    }
    public void sets11092020(String s11092020) {
        this.s11092020=s11092020;
    }

    public String gets11102020() {
        return s11102020;
    }
    public void sets11102020(String s11102020) { this.s11102020=s11102020; }

    public String gets11112020() {
        return s11112020;
    }
    public void sets11112020(String s11112020) {
        this.s11112020=s11112020;
    }

    public String gets11122020() {
        return s11122020;
    }
    public void sets11122020(String s11122020) {
        this.s11122020=s11122020;
    }

    public String gets11132020() {
        return s11132020;
    }
    public void sets11132020(String s11132020) {
        this.s10232020=s11132020;
    }

    public String gets11142020() {
        return s11142020;
    }
    public void sets11142020(String s11142020) {
        this.s11142020=s11142020;
    }

    public String gets11152020() {
        return s11152020;
    }
    public void sets11152020(String s11152020) {
        this.s11152020=s11152020;
    }

    public String gets11162020() {
        return s11162020;
    }
    public void sets11162020(String s11162020) {
        this.s11162020=s11162020;
    }

    public String gets11172020() {
        return s11172020;
    }
    public void sets11172020(String s11172020) {
        this.s11172020=s11172020;
    }

    public String gets11182020() {
        return s11182020;
    }
    public void sets11182020(String s11182020) {
        this.s11182020=s11182020;
    }

    public String gets11192020() {
        return s11192020;
    }
    public void sets11192020(String s11192020) {
        this.s11192020=s11192020;
    }

    public String gets11202020() {
        return s11202020;
    }
    public void sets11202020(String s11202020) {
        this.s11202020=s11202020;
    }

    public String gets11212020() {
        return s11212020;
    }
    public void sets11212020(String s11212020) {
        this.s11212020=s11212020;
    }

    public String gets11222020() {
        return s11222020;
    }
    public void sets11222020(String s11222020) {
        this.s11222020=s11222020;
    }

    public String gets11232020() {
        return s11232020;
    }
    public void sets11232020(String s11232020) {
        this.s10232020=s11232020;
    }

    public String gets11242020() {
        return s11242020;
    }
    public void sets11242020(String s11242020) {
        this.s11242020=s11242020;
    }

    public String gets11252020() {
        return s11252020;
    }
    public void sets11252020(String s11252020) {
        this.s11252020=s11252020;
    }

    public String gets11262020() {
        return s11262020;
    }
    public void sets11262020(String s11262020) {
        this.s11262020=s11262020;
    }

    public String gets11272020() {
        return s11272020;
    }
    public void sets11272020(String s11272020) {
        this.s11272020=s11272020;
    }

    public String gets11282020() {
        return s11282020;
    }
    public void sets11282020(String s11282020) {
        this.s11282020=s11282020;
    }

    public String gets11292020() {
        return s11292020;
    }
    public void sets11292020(String s11292020) {
        this.s11292020=s11292020;
    }

    public String gets11302020() {
        return s11302020;
    }
    public void sets11302020(String s11302020) {
        this.s11302020=s11302020;
    }
}
