package com.example.habit_tracker.Logic.SkillsLogic;

import androidx.fragment.app.Fragment;

public interface FragmentCommListener {
    public void communicate(String comm);
}
